# Cidade Infinita — protótipo Android

Este é um protótipo jogável em estilo isométrico/pseudo-3D, empacotado em um aplicativo Android via WebView.

## Compilar sem PC (usando GitHub Actions)

O projeto inclui `.github/workflows/build-apk.yml`, que compila o APK na nuvem.

1. No navegador do celular, entre em https://github.com e crie uma conta ou entre nela.
2. Crie um repositório novo, por exemplo `cidade-infinita`, e deixe-o **Public** para facilitar o uso do Actions.
3. Envie os arquivos e pastas deste projeto para a raiz do repositório, preservando a estrutura (`app`, `.github`, `build.gradle`, `settings.gradle`, etc.). Não envie apenas o ZIP como um único arquivo.
4. Abra a aba **Actions** do repositório. Se aparecer um aviso, habilite os workflows.
5. Selecione **Compilar APK Android** e toque em **Run workflow** (ou espere a compilação iniciar após o envio dos arquivos).
6. Quando o processo ficar verde/concluído, abra a execução e baixe o artefato **Cidade-Infinita-APK**.
7. Extraia o ZIP do artefato no celular e toque em `app-debug.apk` para instalar. O Android pode pedir autorização para instalar apps dessa fonte.

## Alternativa

Também é possível abrir o projeto no Android Studio em um computador e usar **Build > Build APK(s)**.

## Recursos do protótipo

- Construção de ruas, casas, lojas e fábricas
- Serviços: polícia, hospital e escola
- Rotação de quatro ângulos e zoom
- Rio, montanhas e carros em movimento simples
- Impostos, dinheiro, população e felicidade
- Salvamento local no dispositivo

## Limitações atuais

Não é um clone completo de Cities: Skylines II. O visual 3D é uma projeção isométrica desenhada em Canvas 2D; trânsito e economia são simplificados. As ruas são colocadas em peças de grade, sem desenho livre de curvas. O APK ainda precisa ser compilado pelo workflow antes de instalar.
